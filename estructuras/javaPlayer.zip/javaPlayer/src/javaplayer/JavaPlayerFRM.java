
package javaplayer;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;


public class JavaPlayerFRM {

  private DefaultTableModel dtm;
  private Lista listaPlayer;
  private MediaControl mediaControl;

  public JavaPlayerFRM() {

    try {

      initComponents();
      iniciarListaPlayer();
      actualizarTablaPlayer(listaPlayer);

    } catch (Exception ex) {
      Logger.getLogger(JavaPlayerFRM.class.getName()).log(Level.SEVERE, null, ex);
    }

  }

  private void iniciarListaPlayer(){

    listaPlayer = new Lista();

  }

  private String agregarPista(){

    String nombreArchivoMp3 = "";

    JFileChooser fileChooser = new JFileChooser();

    fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
    fileChooser.setDialogTitle("Abrir MP3");
    fileChooser.setMultiSelectionEnabled(false);

    FileNameExtensionFilter extensionFilter = new FileNameExtensionFilter("Archivos MP3", "mp3");
    fileChooser.setFileFilter(extensionFilter);

    int result = fileChooser.showOpenDialog(this);


    if (result == JFileChooser.APPROVE_OPTION) {

      nombreArchivoMp3 = fileChooser.getSelectedFile().getAbsolutePath();

    }

    return nombreArchivoMp3;

  }


  private void actualizarTablaPlayer(Lista listaPlayer) throws Exception{

    dtm = new DefaultTableModel(new String[]{"Título"}, 0);
    int rowCount = listaPlayer.getTamanio();

    for(int i = 0; i < rowCount; i++){

      Object[] row = new Object[1];

      row[0] = listaPlayer.getValor(i);

      dtm.addRow(row);
    }

    tablaPlayer.setModel(dtm);


  }



  @SuppressWarnings("unchecked")
  // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
  private void initComponents() {

    jScrollPane1 = new javax.swing.JScrollPane();
    tablaPlayer = new javax.swing.JTable();
    cmdAgregar = new javax.swing.JButton();
    reproducir = new javax.swing.JButton();
    detener = new javax.swing.JButton();
    salir = new javax.swing.JButton();
    siguiente = new javax.swing.JButton();
    anterior = new javax.swing.JButton();

    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

    tablaPlayer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null},
                    {null, null, null, null}
            },
            new String [] {
                    "Title 1", "Title 2", "Title 3", "Title 4"
            }
    ));
    jScrollPane1.setViewportView(tablaPlayer);

    cmdAgregar.setText("Agregar");
    cmdAgregar.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        cmdAgregarActionPerformed(evt);
      }
    });

    reproducir.setText("Reproducir");
    reproducir.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        reproducirActionPerformed(evt);
      }
    });

    detener.setText("Detener");

    salir.setText("Salir");
    salir.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent evt) {
        salirActionPerformed(evt);
      }
    });

    siguiente.setText("Siguiente >>");

    anterior.setText("<< Anterior");

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmdAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(reproducir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(detener, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(salir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(siguiente, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                                    .addComponent(anterior, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addContainerGap())
    );
    layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                            .addComponent(cmdAgregar)
                                            .addGap(61, 61, 61)
                                            .addComponent(reproducir)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(anterior)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(siguiente)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(detener)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(salir)
                                            .addGap(21, 21, 21))))
    );

    pack();
  }// </editor-fold>//GEN-END:initComponents

  private void cmdAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdAgregarActionPerformed
    try {

      listaPlayer.agregarAlFinal(agregarPista());

      actualizarTablaPlayer(listaPlayer);

    } catch (Exception ex) {
      Logger.getLogger(JavaPlayerFRM.class.getName()).log(Level.SEVERE, null, ex);
    }

  }//GEN-LAST:event_cmdAgregarActionPerformed

  private void reproducirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reproducirActionPerformed

    try {
      mediaControl = new MediaControl(listaPlayer.getValor(0));
      mediaControl.ejecutar();
    } catch (Exception ex) {
      Logger.getLogger(JavaPlayerFRM.class.getName()).log(Level.SEVERE, null, ex);
    }

  }//GEN-LAST:event_reproducirActionPerformed

  private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
    dispose();
  }//GEN-LAST:event_salirActionPerformed

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JButton anterior;
  private javax.swing.JButton cmdAgregar;
  private javax.swing.JButton detener;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JButton reproducir;
  private javax.swing.JButton salir;
  private javax.swing.JButton siguiente;
  private javax.swing.JTable tablaPlayer;
  // End of variables declaration//GEN-END:variables


}
