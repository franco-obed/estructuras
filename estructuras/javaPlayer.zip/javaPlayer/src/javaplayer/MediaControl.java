
package javaplayer;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class MediaControl {

  private String fileName;
  private Player player;
  private FileInputStream fileInputStream;
  private BufferedInputStream bufferedInputStream;
  
  public MediaControl(String fileName) {
    this.fileName = fileName;
    
  }
  
  public void cerrar(){
    if(player != null)
      player.close();
  }
  
  public void ejecutar(){
    
    try {
    
      fileInputStream = new FileInputStream(fileName);
      bufferedInputStream = new BufferedInputStream(fileInputStream);
    
      player = new Player(bufferedInputStream);
    
      player.play();
      new Thread(){
       
        public void run(){
          try {
            player.play();
          } catch (JavaLayerException ex) {
            Logger.getLogger(MediaControl.class.getName()).log(Level.SEVERE, null, ex);
          }
        }
        
      }.start();
      
    } catch (FileNotFoundException ex) {
      Logger.getLogger(MediaControl.class.getName()).log(Level.SEVERE, null, ex);
    } catch (JavaLayerException ex) {
      Logger.getLogger(MediaControl.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    
  }
  
  public boolean isComplete(){
    return player.isComplete();
  }
          
}
