
package javaplayer;


public class Lista {
  private Nodo inicio;
  private int tamanio;

  public void Lista(){
    inicio = null;
    tamanio = 0;
  }

  public boolean esVacia(){
    return inicio == null;
  }

  public int getTamanio(){
    return tamanio;
  }

  public void agregarAlFinal(String nombreArchivo){

    Nodo nuevo = new Nodo();

    nuevo.setNombreArchivo(nombreArchivo);

    if (esVacia()) {

      inicio = nuevo;

    } else{

      Nodo aux = inicio;

      while(aux.getSiguiente() != null){
        aux = aux.getSiguiente();
      }

      aux.setSiguiente(nuevo);
    }

    tamanio++;
  }

  public String getValor(int posicion) throws Exception{

    if(posicion >= 0 && posicion < tamanio){

      if (posicion == 0) {

        return inicio.getNombreArchivo();

      }else{

        Nodo aux = inicio;

        for (int i = 0; i < posicion; i++) {
          aux = aux.getSiguiente();
        }

        return aux.getNombreArchivo();
      }

    } else {
      throw new Exception("Posicion inexistente en la lista.");
    }
  }

  public void removerPorPosicion(int posicion){

    if(posicion>=0 && posicion<tamanio){

      if(posicion == 0){

        inicio = inicio.getSiguiente();
      } else {

        Nodo aux = inicio;

        for (int i = 0; i < posicion-1; i++) {
          aux = aux.getSiguiente();
        }

        Nodo siguiente = aux.getSiguiente();

        aux.setSiguiente(siguiente.getSiguiente());
      }

      tamanio--;
    }
  }

  public void eliminarContenido(){

    inicio = null;

    tamanio = 0;
  }

  public void listar(){

    if (!esVacia()) {

      Nodo aux = inicio;

      int i = 0;

      while(aux != null){

        System.out.print(i + ".[ " + aux.getNombreArchivo()+ " ]" + " ->  ");

        aux = aux.getSiguiente();

        i++;
      }
    }
  }

}



