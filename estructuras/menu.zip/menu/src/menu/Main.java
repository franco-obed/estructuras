package menu;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        int id = 0;
        int num = 0;
        int Opc = 0;
        double precio = 0;


        //MENU
        System.out.println("--------- MENU ------------- ");
        System.out.println("1.  Hamburguesas        ");
        System.out.println("2.  Papas fritas        ");
        System.out.println("3.  Refrescos           ");
        System.out.println("4.  Aros de cebolla     ");
        System.out.println("5.  Cerveza             ");


        System.out.println("");
        System.out.println("\n-----Seleccione una opcion-----");//Funcion de opciones - Variable Opc
        Opc = sc.nextInt();

        if (Opc == 1) {//1. Hamburguesas
            System.out.println("Se Ha  elegido Hamburguesas\n");
            System.out.println("¿Cuantas hamburguesas necesita?");
            num = sc.nextInt();

            precio = (75.00 * num);
            id = 1;
            System.out.println("======== Tu orden ========");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", "ID", "DESCRIPCION", "CANTIDAD", "PRECIO");
            System.out.println("");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", id, " Hamburguesa(s) ", num , precio);
        }

        if (Opc == 2) {//2. Papas fritas
            System.out.println("Se seleccionaron Papas fritas\n");
            System.out.println("¿Cuantas papas fritas deseas ordenar?");
            num = sc.nextInt();

            precio = (55.00 * num);
            id = 2;
            System.out.println("======== Tu orden ========");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", "ID", "DESCRIPCION", "CANTIDAD", "PRECIO");
            System.out.println("");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", id, " Porcion(es) de papas fritas ", num , precio);
        }

        if (Opc == 3) {//3. Refrescos
            System.out.println("Se Ha Selecicono Refrescos\n");
            System.out.println("¿Cuantos refrescos deseas ordenar?");
            num = sc.nextInt();

            precio = (20.00 * num);
            id = 3;
            System.out.println("======== Tu orden ========");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", "ID", "DESCRIPCION", "CANTIDAD", "PRECIO");
            System.out.println("");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", id, " Refresco(s) ", num , precio);
        }

        if (Opc == 4) {//4. Aros de cebolla
            System.out.println("Se  Ha Selecicono Aros de cebolla\n");
            System.out.println("¿Cuantas porciones de aros de cebolla deseas ordenar?");
            num = sc.nextInt();

            precio = (40.00 * num);
            id = 4;
            System.out.println("======== Tu orden ========");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", "ID", "DESCRIPCION", "CANTIDAD", "PRECIO");
            System.out.println("");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", id, " Porcion(es) de aros de cebolla ", num , precio);
        }

        if (Opc == 5) {//5. Cerveza
            System.out.println("Se Ha seleciconado Cerveza\n");
            System.out.println("¿Cuantas cervezas deseas ordenar?");
            num = sc.nextInt();

            precio = (50.00 * num);
            id = 5;
            System.out.println("======== Tu orden ========");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", "ID", "DESCRIPCION", "CANTIDAD", "PRECIO");
            System.out.println("");
            System.out.printf("%-5s|%-20s|%-20s|%-20s", id, " Cerveza(s) ", num , precio);
        }
    }

}
