package listaTelefonica;

class Contacto implements Comparable<Contacto> {

    private String alias;
    private String telefono_fijo;
    private String telefono_movil;
    private String correo;

    @Override
    public boolean equals(Object contacto) {
        return this==contacto || (contacto instanceof Contacto && alias.equals(((Contacto)contacto).alias));
    }

    @Override
    public int compareTo(Contacto contacto) {
        return alias.compareTo(contacto.alias);
    }

    @Override
    public String toString() {
        return
                "alias         : " + alias + "\n" +
                        "telefono fijo : " + telefono_fijo + "\n" +
                        "telefono movil: " + telefono_movil + "\n" +
                        "correo        : " + correo + "\n";
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getTelefono_fijo() {
        return telefono_fijo;
    }

    public void setTelefono_fijo(String telefono_fijo) {
        this.telefono_fijo = telefono_fijo;
    }

    public String getTelefono_movil() {
        return telefono_movil;
    }

    public void setTelefono_movil(String telefono_movil) {
        this.telefono_movil = telefono_movil;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

}